Group member details:

Nada Tade - nxt180027
Rakesh Kumar Mahato - rkm190000
Nimrat Bedi - nxb200004


Instructions:

Run the code on google collab.
OR
Open the code on any python interpreter and run the code.
  